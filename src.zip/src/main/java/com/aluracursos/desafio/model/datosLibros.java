package com.aluracursos.desafio.model;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;


@JsonIgnoreProperties(ignoreUnknown = true)

public record datosLibros(

        @JsonAlias("title")String titulo,
        @JsonAlias("authors")List<DatosAutor> autor,
        @JsonAlias("lenguages")List<String> idiomas,
        @JsonAlias("download_count")Double numeroDeDescargas
) {

    @Override
    public String toString() {

        String nombreAutor = "No disponible";
        if (autor != null && !autor.isEmpty()) {
            nombreAutor = autor.get(0).nombre();
        }

        String idioma = "No disponible";
        if (idiomas != null && !idiomas.isEmpty()) {
            idioma = idiomas.get(0);
        }

        return """
                ══════════════════════════════
                       📚 LIBRO ENCONTRADO
                ══════════════════════════════
                📖 Título: %s
                ✍ Autor: %s
                🌍 Idioma: %s
                ⬇ Descargas: %.0f
                ══════════════════════════════
                """.formatted(
                titulo,
                nombreAutor,
                idioma,
                numeroDeDescargas != null ? numeroDeDescargas : 0.0
        );
    }


}

