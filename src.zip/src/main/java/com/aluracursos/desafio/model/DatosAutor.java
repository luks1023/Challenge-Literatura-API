package com.aluracursos.desafio.model;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@JsonIgnoreProperties(ignoreUnknown = true)

public record DatosAutor(



        String nombre,
        Integer fechaDeNacimiento,
        Integer fechaDeFallecimiento
) {}
