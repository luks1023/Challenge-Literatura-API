package com.aluracursos.desafio.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.aluracursos.desafio.model.Libro;

public interface LibroRepository extends JpaRepository<Libro, Long> {
}