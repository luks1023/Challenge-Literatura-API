package com.aluracursos.desafio.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.aluracursos.desafio.model.Autor;

import java.util.Optional;

public interface AutorRepository extends JpaRepository<Autor, Long> {

    Optional<Autor> findByNombre(String nombre);
}