package com.aluracursos.desafio.Principal;

import com.aluracursos.desafio.model.*;
import com.aluracursos.desafio.repository.AutorRepository;
import com.aluracursos.desafio.repository.LibroRepository;
import com.aluracursos.desafio.service.ConsumoAPI;
import com.aluracursos.desafio.service.ConvierteDatos;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;
import java.util.Scanner;

@Component
public class Principal {

    private Scanner teclado = new Scanner(System.in);
    private final String URL_BASE = "https://gutendex.com/books/";

    @Autowired
    private LibroRepository libroRepository;

    @Autowired
    private AutorRepository autorRepository;

    @Autowired
    private ConsumoAPI consumoAPI;

    @Autowired
    private ConvierteDatos conversor;

    public void muestraElMenu() {
        int opcion = -1;

        while (opcion != 0) {

            System.out.println("""
                    
                    
                    
                      *****************************************
                    📚 LITERALURA - Catálogo de Libros
                    
                    1 - Buscar libro por título
                    2 - Listar libros guardados
                    0 - Salir
                    """);

            opcion = teclado.nextInt();
            teclado.nextLine();

            switch (opcion) {
                case 1:
                    buscarLibroPorTitulo();
                    break;
                case 2:
                    listarLibrosGuardados();
                    break;
                case 0:
                    System.out.println("Cerrando aplicación...");
                    break;
                default:
                    System.out.println("Opción inválida");
            }
        }
    }

    private void buscarLibroPorTitulo() {

        System.out.println("Ingrese el nombre del libro:");
        String tituloLibro = teclado.nextLine();

        String json = consumoAPI.obtenerDatos(
                URL_BASE + "?search=" + tituloLibro.replace(" ", "+")
        );

        Datos datos = conversor.obtenerDatos(json, Datos.class);

        Optional<datosLibros> libroBuscado = datos.resultados()
                .stream()
                .findFirst();

        if (libroBuscado.isPresent()) {

            datosLibros datosLibro = libroBuscado.get();
            DatosAutor datosAutor = datosLibro.autor().get(0);

            // 🔎 Buscar autor en BD
            Optional<Autor> autorExistente =
                    autorRepository.findByNombre(datosAutor.nombre());

            Autor autor;

            if (autorExistente.isPresent()) {
                autor = autorExistente.get();
            } else {
                autor = new Autor(datosAutor);
                autorRepository.save(autor);
            }

            Libro libro = new Libro(datosLibro, autor);
            libroRepository.save(libro);

            System.out.println("✅ Libro guardado correctamente");

        } else {
            System.out.println("❌ Libro no encontrado");
        }
    }

    private void listarLibrosGuardados() {
        var libros = libroRepository.findAll();

        if (libros.isEmpty()) {
            System.out.println("No hay libros guardados.");
        } else {
            libros.forEach(libro ->
                    System.out.println("📚 " + libro.getTitulo())
            );
        }
    }
}